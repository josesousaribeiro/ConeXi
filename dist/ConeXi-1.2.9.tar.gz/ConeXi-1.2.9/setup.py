from distutils.core import setup
setup(name='ConeXi',
      description='Combining Explanations and Interpretations - ConeXi.',
      author='José de Sousa Ribeiro Filho',
      author_email='jose.sousa.filho@gmail.com',
      version='1.2.9',
      packages=['combineranks']
      )

